/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sauravhathi.onlineretailapplication;

/**
 *
 * @author saura
 */
public class Product {

    private int id;
    private String name;
    private double price;
    private String description;
    private String category;

    public Product(int id, String name, double price, String description, String category) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.description = description;
        this.category = category;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public String getDescription() {
        return description;
    }

    public String getCategory() {
        return category;
    }

    public static Product fromString(String line) throws IllegalArgumentException {
        String[] values = line.split(",");
        if (values.length != 5) {
            throw new IllegalArgumentException("Invalid product data: " + line);
        }
        int id = Integer.parseInt(values[0]);
        String name = values[1];
        double price = Double.parseDouble(values[2]);
        String description = values[3];
        String category = values[4];
        return new Product(id, name, price, description, category);
    }

    @Override
    public String toString() {
        return id + "," + name + "," + price + "," + description + "," + category;
    }
}
